# Q68. Longest Subarray with Max-Min <= K
from collections import deque

def longest_subarray(A, K):
    maxd, mind = deque(), deque()
    left = best = 0
    for right in range(len(A)):
        while maxd and A[maxd[-1]] <= A[right]:
            maxd.pop()
        while mind and A[mind[-1]] >= A[right]:
            mind.pop()
        maxd.append(right)
        mind.append(right)
        while A[maxd[0]] - A[mind[0]] > K:
            left += 1
            if maxd[0] < left:
                maxd.popleft()
            if mind[0] < left:
                mind.popleft()
        best = max(best, right - left + 1)
    return best

if __name__ == "__main__":
    N, K = map(int, input("Enter N and K: ").split())
    A = list(map(int, input("Enter array: ").split()))
    print(longest_subarray(A, K))
