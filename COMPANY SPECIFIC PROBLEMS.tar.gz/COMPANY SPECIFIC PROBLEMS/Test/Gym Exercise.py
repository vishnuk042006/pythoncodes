def Tired(a,b,c):
    count=0
    for i in range(b*2):
        a=a-c[int(i/2)]
        if(a>0):
            count+=1
        else:
            count+=1
            break
    if(a>0):
        return -1
    else:
        return count

E = int(input("Enter the total Energy: "))
N = int(input("Total Exersize: "))
A = [int(input("Energy required for each exersize: ")) for _ in range(N)]
A.sort(reverse=True)
print(Tired(E,N,A))


