import bisect
A=list(map(int,input().split())); T=int(input())
lo=bisect.bisect_left(A,T); hi=bisect.bisect_right(A,T)-1
if lo>hi or A[lo]!=T: print(-1,-1)
else: print(lo,hi)