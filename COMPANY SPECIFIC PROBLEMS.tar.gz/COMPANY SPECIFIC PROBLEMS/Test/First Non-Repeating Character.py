from collections import Counter
S=input()
freq=Counter(S)
for c in S:
    if freq[c]==1: print(c); exit()
print('None')