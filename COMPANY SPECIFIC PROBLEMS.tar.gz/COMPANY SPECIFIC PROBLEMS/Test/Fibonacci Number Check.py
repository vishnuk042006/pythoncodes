n = int(input())   
a=0
b=1
while a<=n:
    if(a==n):
        print("Yes")
        break
    c=a+b
    a=b
    b=c
if(a!=n):
   print("No")
