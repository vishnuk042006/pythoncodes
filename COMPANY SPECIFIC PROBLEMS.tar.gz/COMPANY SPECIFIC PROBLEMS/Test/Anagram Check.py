S=[list(input().lower()) for _ in range(2)]
print(S[0].sort()==S[1].sort())