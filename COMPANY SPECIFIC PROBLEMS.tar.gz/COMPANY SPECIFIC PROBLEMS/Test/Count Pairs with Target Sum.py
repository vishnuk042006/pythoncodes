N = int(input())
K = int(input())
A = [int(input()) for _ in range(N)]
H = []
for i in range(N):
    for j in range(i,N):
        if(A[i]+A[j]==K):
            H.append((A[i],A[j]))
print(H)