S = input()
clean="".join(c.lower() for c in S if c.isalnum())
print(clean==clean[::-1])