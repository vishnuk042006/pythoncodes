N = int(input())
K = int(input())
A = [int(input()) for _ in range(N)]
for i in range(K):
    temp=A.pop(0)
    A.append(temp)
print(A)
