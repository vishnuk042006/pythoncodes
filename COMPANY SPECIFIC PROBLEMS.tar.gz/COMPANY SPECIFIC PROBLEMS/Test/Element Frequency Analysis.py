N = int(input())
A = [int(input()) for _ in range(N)]
d={}
dis=0
rep=0
for i in set(A):
    count=0
    for j in range(i,N):
        if(i==A[j]):
            count+=1
    d[i]=count
for i in d.values():
    if i==0:
        dis+=1
    else:
        rep+=1
print(rep,dis)