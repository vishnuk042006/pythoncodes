import math
N=int(input())
for d in str(math.factorial(N)): print(d)