# Q54. BFS Shortest Path in Grid with Obstacles
from collections import deque

def shortest_path(grid):
    M, N = len(grid), len(grid[0])
    if grid[0][0] == 1 or grid[M - 1][N - 1] == 1:
        return -1
    dist = [[-1] * N for _ in range(M)]
    dist[0][0] = 0
    q = deque([(0, 0)])
    while q:
        r, c = q.popleft()
        for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < M and 0 <= nc < N and grid[nr][nc] == 0 and dist[nr][nc] == -1:
                dist[nr][nc] = dist[r][c] + 1
                q.append((nr, nc))
    return dist[M - 1][N - 1]

if __name__ == "__main__":
    M, N = map(int, input("Enter M and N: ").split())
    grid = [list(map(int, input().split())) for _ in range(M)]
    print(shortest_path(grid))
