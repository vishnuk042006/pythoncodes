# Q36. Maximum Vacation Days (Obligation Gap)
def max_vacation(N, obligations):
    obs = sorted(obligations)
    obs = [0] + obs + [N + 1]
    best = 0
    for i in range(1, len(obs)):
        best = max(best, obs[i] - obs[i - 1] - 1)
    return best

if __name__ == "__main__":
    N, M = map(int, input("Enter N and M: ").split())
    obs = list(map(int, input().split())) if M > 0 else []
    print(max_vacation(N, obs))
