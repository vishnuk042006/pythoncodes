def Non_Rep(a):
    if a==[]:
        return -1
    b=a.pop(0)
    if b in a:
        a.remove(b)
        return Non_Rep(a)
    else:
        return b
    
S = [1,2,1,2,3,4,3,4]
print(Non_Rep(S))