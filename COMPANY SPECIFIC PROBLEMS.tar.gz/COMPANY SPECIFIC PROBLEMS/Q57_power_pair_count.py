# Q57. Power Pair Count
def count_power_pairs(N, X, D):
    count = 0
    for A in range(1, N + 1):
        for B in range(1, N + 1):
            if (A + B) % D == 0:
                # Check A**B <= X without overflow issues, cap growth
                if A == 1:
                    val = 1
                else:
                    val = None
                    acc = 1
                    for _ in range(B):
                        acc *= A
                        if acc > X:
                            val = acc
                            break
                    if val is None:
                        val = acc
                if val <= X:
                    count += 1
    return count

if __name__ == "__main__":
    N, X, D = map(int, input("Enter N, X, D: ").split())
    print(count_power_pairs(N, X, D))
