# Q37. Same Digit Base Conversion
# Find the smallest base K >= 2 in which M is written as a two-digit
# repdigit "dd" (i.e. M = d*(K+1) for some digit d with 1 <= d < K).
# Base K = M-1 always works (giving "11"), so that's the fallback.
def smallest_base(M):
    for K in range(2, M):
        if M % (K + 1) == 0:
            d = M // (K + 1)
            if 1 <= d < K:
                return K
    return M - 1

if __name__ == "__main__":
    M = int(input("Enter M: "))
    print(smallest_base(M))
