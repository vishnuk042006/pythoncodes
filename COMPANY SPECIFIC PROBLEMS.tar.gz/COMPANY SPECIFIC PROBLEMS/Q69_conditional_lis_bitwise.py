# Q69. Conditional LIS with Bitwise Constraint
def conditional_lis(A):
    N = len(A)
    dp = [1] * N
    for i in range(N):
        for j in range(i):
            if A[j] < A[i] and (A[j] & A[i]) * 2 < (A[j] | A[i]):
                dp[i] = max(dp[i], dp[j] + 1)
    return max(dp) if dp else 0

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = list(map(int, input("Enter array: ").split()))
    print(conditional_lis(A))
