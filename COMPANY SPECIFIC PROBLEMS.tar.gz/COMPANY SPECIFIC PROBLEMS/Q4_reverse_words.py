# Q4. Reverse Words in Sentence
def reverse_words(s):
    return " ".join(s.split()[::-1])

if __name__ == "__main__":
    S = input("Enter sentence: ")
    print(reverse_words(S))
