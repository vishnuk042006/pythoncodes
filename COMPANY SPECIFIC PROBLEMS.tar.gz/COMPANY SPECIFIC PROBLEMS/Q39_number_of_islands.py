# Q39. Number of Islands (DFS)
def num_islands(grid):
    grid = [list(row) for row in grid]
    M, N = len(grid), len(grid[0])

    def dfs(r, c):
        if r < 0 or r >= M or c < 0 or c >= N or grid[r][c] != '1':
            return
        grid[r][c] = '0'
        for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            dfs(r + dr, c + dc)

    count = 0
    for r in range(M):
        for c in range(N):
            if grid[r][c] == '1':
                dfs(r, c)
                count += 1
    return count

if __name__ == "__main__":
    M, N = map(int, input("Enter M and N: ").split())
    grid = [input() for _ in range(M)]
    print(num_islands(grid))
