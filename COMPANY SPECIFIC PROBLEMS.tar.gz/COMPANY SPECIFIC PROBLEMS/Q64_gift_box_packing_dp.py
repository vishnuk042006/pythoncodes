# Q64. Gift Box Packing - K Boxes Distinct Count DP
from collections import defaultdict

def max_total_value(N, K, G):
    dist = [[0] * N for _ in range(N)]
    for i in range(N):
        seen = defaultdict(int)
        for j in range(i, N):
            seen[G[j]] += 1
            dist[i][j] = len(seen)
    NEG = float('-inf')
    dp = [[NEG] * N for _ in range(K + 1)]
    for j in range(N):
        dp[1][j] = dist[0][j]
    for k in range(2, K + 1):
        for j in range(k - 1, N):
            for i in range(k - 1, j + 1):
                if dp[k - 1][i - 1] != NEG:
                    dp[k][j] = max(dp[k][j], dp[k - 1][i - 1] + dist[i][j])
    return dp[K][N - 1]

if __name__ == "__main__":
    N, K = map(int, input("Enter N and K: ").split())
    G = list(map(int, input("Enter gifts: ").split()))
    print(max_total_value(N, K, G))
