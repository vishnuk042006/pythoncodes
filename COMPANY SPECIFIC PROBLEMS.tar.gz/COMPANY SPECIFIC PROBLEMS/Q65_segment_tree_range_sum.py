# Q65. Segment Tree - Range Sum with Point Updates
class SegTree:
    def __init__(self, A):
        self.N = len(A)
        self.t = [0] * (4 * self.N)
        self._build(A, 1, 0, self.N - 1)

    def _build(self, A, nd, s, e):
        if s == e:
            self.t[nd] = A[s]
            return
        m = (s + e) // 2
        self._build(A, 2 * nd, s, m)
        self._build(A, 2 * nd + 1, m + 1, e)
        self.t[nd] = self.t[2 * nd] + self.t[2 * nd + 1]

    def update(self, i, v, nd=1, s=None, e=None):
        if s is None:
            s, e = 0, self.N - 1
        if s == e:
            self.t[nd] = v
            return
        m = (s + e) // 2
        if i <= m:
            self.update(i, v, 2 * nd, s, m)
        else:
            self.update(i, v, 2 * nd + 1, m + 1, e)
        self.t[nd] = self.t[2 * nd] + self.t[2 * nd + 1]

    def query(self, l, r, nd=1, s=None, e=None):
        if s is None:
            s, e = 0, self.N - 1
        if r < s or e < l:
            return 0
        if l <= s and e <= r:
            return self.t[nd]
        m = (s + e) // 2
        return self.query(l, r, 2 * nd, s, m) + self.query(l, r, 2 * nd + 1, m + 1, e)

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = list(map(int, input("Enter array: ").split()))
    st = SegTree(A)
    Q = int(input("Enter Q: "))
    for _ in range(Q):
        ops = list(map(int, input().split()))
        if ops[0] == 1:  # query L R (1-indexed)
            print(st.query(ops[1] - 1, ops[2] - 1))
        else:  # update index value (1-indexed)
            st.update(ops[1] - 1, ops[2])
