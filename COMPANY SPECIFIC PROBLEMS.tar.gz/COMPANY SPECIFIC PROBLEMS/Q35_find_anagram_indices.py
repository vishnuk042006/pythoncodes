# Q35. Find All Anagram Indices
from collections import Counter

def find_anagrams(s, p):
    k = len(p)
    if k > len(s):
        return []
    res = []
    pc = Counter(p)
    wc = Counter(s[:k])
    if wc == pc:
        res.append(0)
    for i in range(1, len(s) - k + 1):
        wc[s[i - 1]] -= 1
        if wc[s[i - 1]] == 0:
            del wc[s[i - 1]]
        wc[s[i + k - 1]] += 1
        if wc == pc:
            res.append(i)
    return res

if __name__ == "__main__":
    S = input("Enter S: ")
    P = input("Enter P: ")
    print(find_anagrams(S, P))
