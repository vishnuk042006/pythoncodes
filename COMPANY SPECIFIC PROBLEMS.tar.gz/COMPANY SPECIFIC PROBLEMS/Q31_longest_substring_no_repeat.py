# Q31. Longest Substring Without Repeating Characters
def longest_unique_substring(s):
    char_idx = {}
    left = best = 0
    for right, ch in enumerate(s):
        if ch in char_idx and char_idx[ch] >= left:
            left = char_idx[ch] + 1
        char_idx[ch] = right
        best = max(best, right - left + 1)
    return best

if __name__ == "__main__":
    S = input("Enter string: ")
    print(longest_unique_substring(S))
