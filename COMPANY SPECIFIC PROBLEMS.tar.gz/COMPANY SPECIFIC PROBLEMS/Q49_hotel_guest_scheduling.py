# Q49. Hotel Guest Scheduling - Minimize Unhappiness
def min_unhappiness(C):
    C = sorted(C)
    return sum(abs(c - i - 1) for i, c in enumerate(C))

if __name__ == "__main__":
    N = int(input("Enter N: "))
    C = [int(input()) for _ in range(N)]
    print(min_unhappiness(C))
