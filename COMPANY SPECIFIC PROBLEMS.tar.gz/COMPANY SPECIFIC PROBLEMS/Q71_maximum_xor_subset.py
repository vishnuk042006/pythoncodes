# Q71. Maximum XOR Subset
def max_xor_subset(A):
    basis = [0] * 30
    for x in A:
        for i in range(29, -1, -1):
            if not (x >> i) & 1:
                continue
            if not basis[i]:
                basis[i] = x
                break
            x ^= basis[i]
    res = 0
    for b in basis:
        res = max(res, res ^ b)
    return res

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = list(map(int, input("Enter array: ").split()))
    print(max_xor_subset(A))
