# Q72. Minimum Array Minimization Cost
def min_cost(A, X, Y):
    total = 0
    for v in A:
        # For each element independently: cost via repeated -1 subarray ops (v*X)
        # vs a direct set-to-zero op (Y). Pick the cheaper.
        total += min(v * X, Y)
    return total

if __name__ == "__main__":
    N, X, Y = map(int, input("Enter N, X, Y: ").split())
    A = list(map(int, input("Enter array: ").split()))
    print(min_cost(A, X, Y))
