# Q44. Minimum Window Substring
from collections import Counter

def min_window(s, t):
    need = Counter(t)
    have = {}
    formed = 0
    req = len(need)
    l = 0
    best = (float('inf'), 0, 0)
    for r, c in enumerate(s):
        have[c] = have.get(c, 0) + 1
        if c in need and have[c] == need[c]:
            formed += 1
        while formed == req:
            if r - l + 1 < best[0]:
                best = (r - l + 1, l, r)
            have[s[l]] -= 1
            if s[l] in need and have[s[l]] < need[s[l]]:
                formed -= 1
            l += 1
    return '' if best[0] == float('inf') else s[best[1]:best[2] + 1]

if __name__ == "__main__":
    S = input("Enter S: ")
    T = input("Enter T: ")
    print(min_window(S, T))
