# Q18. Prime Number Check and Sieve
def sieve(N):
    is_prime = [True] * (N + 1)
    is_prime[0:2] = [False, False]
    i = 2
    while i * i <= N:
        if is_prime[i]:
            for j in range(i * i, N + 1, i):
                is_prime[j] = False
        i += 1
    return [i for i in range(N + 1) if is_prime[i]]

if __name__ == "__main__":
    N = int(input("Enter N: "))
    print(*sieve(N))
