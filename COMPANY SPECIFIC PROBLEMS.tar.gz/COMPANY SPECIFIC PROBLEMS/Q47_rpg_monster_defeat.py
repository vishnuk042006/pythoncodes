# Q47. RPG Monster Defeat (Greedy Sorting)
def max_monsters_defeated(E, monsters):
    monsters = sorted(monsters, key=lambda x: x[0])
    count = 0
    for p, b in monsters:
        if E >= p:
            E += b
            count += 1
    return count

if __name__ == "__main__":
    N, E = map(int, input("Enter N and E: ").split())
    monsters = [tuple(map(int, input().split())) for _ in range(N)]
    print(max_monsters_defeated(E, monsters))
