# Q46. Heroes vs Villains Battle
# M heroes, each starting with health H, must defeat all villains in order.
# Fighting a villain reduces the hero's HP by the villain's power. If a
# hero's HP would drop below 0, that hero is defeated, the next fresh hero
# (full HP) takes over, and re-fights the SAME villain. Find the minimum
# number of villains to remove from the front so that all remaining
# villains can be defeated without running out of heroes.
def can_win(V, start, M, H):
    heroes_left = M
    hp = H
    for i in range(start, len(V)):
        while True:
            new_hp = hp - V[i]
            if new_hp < 0:
                heroes_left -= 1
                if heroes_left <= 0:
                    return False
                hp = H  # fresh hero retries the same villain
            else:
                hp = new_hp
                break
    return True

def min_villains_to_remove(N, M, H, V):
    for i in range(N + 1):
        if can_win(V, i, M, H):
            return i
    return N

if __name__ == "__main__":
    N = int(input("Enter N: "))
    M = int(input("Enter M: "))
    H = int(input("Enter H: "))
    V = [int(input()) for _ in range(N)]
    print(min_villains_to_remove(N, M, H, V))
