S=input()
print(' '.join(S.split()[::-1]))