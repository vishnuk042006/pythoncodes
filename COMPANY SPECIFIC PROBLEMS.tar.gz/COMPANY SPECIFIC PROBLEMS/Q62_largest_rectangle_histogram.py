# Q62. Largest Rectangle in Histogram
def largest_rectangle(H):
    H = H + [0]
    stack = []
    best = 0
    for i, h in enumerate(H):
        start = i
        while stack and stack[-1][1] >= h:
            idx, ht = stack.pop()
            best = max(best, ht * (i - idx))
            start = idx
        stack.append((start, h))
    return best

if __name__ == "__main__":
    N = int(input("Enter N: "))
    H = list(map(int, input("Enter heights: ").split()))
    print(largest_rectangle(H))
