# Q67. Fenwick Tree (BIT) - Prefix Sum Queries
class BIT:
    def __init__(self, n):
        self.n = n
        self.t = [0] * (n + 1)

    def update(self, i, v):
        while i <= self.n:
            self.t[i] += v
            i += i & (-i)

    def query(self, i):
        s = 0
        while i > 0:
            s += self.t[i]
            i -= i & (-i)
        return s

if __name__ == "__main__":
    N = int(input("Enter N: "))
    bit = BIT(N)
    Q = int(input("Enter Q: "))
    for _ in range(Q):
        ops = list(map(int, input().split()))
        if ops[0] == 1:  # query prefix sum up to index
            print(bit.query(ops[1]))
        else:  # add value at index
            bit.update(ops[1], ops[2])
