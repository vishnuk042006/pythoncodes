# Q38. Word Break Problem
def word_break(s, words):
    words = set(words)
    n = len(s)
    dp = [False] * (n + 1)
    dp[0] = True
    for i in range(1, n + 1):
        for j in range(i):
            if dp[j] and s[j:i] in words:
                dp[i] = True
                break
    return dp[n]

if __name__ == "__main__":
    S = input("Enter string: ")
    words = input("Enter dictionary words (space separated): ").split()
    print(word_break(S, words))
