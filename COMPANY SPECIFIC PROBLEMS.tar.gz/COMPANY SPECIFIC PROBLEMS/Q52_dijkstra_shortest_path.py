# Q52. Shortest Path in Weighted Graph (Dijkstra)
import heapq

def dijkstra(V, edges, S):
    g = [[] for _ in range(V)]
    for u, v, w in edges:
        g[u].append((v, w))
    dist = [float('inf')] * V
    dist[S] = 0
    heap = [(0, S)]
    while heap:
        d, u = heapq.heappop(heap)
        if d > dist[u]:
            continue
        for v, w in g[u]:
            if dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                heapq.heappush(heap, (dist[v], v))
    return dist

if __name__ == "__main__":
    V, E, S = map(int, input("Enter V, E, S: ").split())
    edges = [tuple(map(int, input().split())) for _ in range(E)]
    dist = dijkstra(V, edges, S)
    print(*(-1 if d == float('inf') else d for d in dist))
