# Q45. Road Building - Minimum Digging Days
def can_achieve(L, days):
    N = len(L)
    max_r = (1 << days) - 1
    cur = L[:]
    for i in range(1, N):
        need = cur[i] - (cur[i - 1] - 1)
        if need > 0:
            if need > max_r:
                return False
            cur[i] -= need
    return True

def min_days(L):
    lo, hi = 0, 62
    while lo < hi:
        mid = (lo + hi) // 2
        if can_achieve(L, mid):
            hi = mid
        else:
            lo = mid + 1
    return lo

if __name__ == "__main__":
    N = int(input("Enter N: "))
    L = [int(input()) for _ in range(N)]
    print(min_days(L))
