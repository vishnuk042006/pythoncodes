# Q48. Ball Color Probability - Bucket Chain
def bucket_chain_probability(buckets):
    N = len(buckets)
    K = len(buckets[0])
    sums = [sum(row) for row in buckets]
    p = [buckets[0][j] / sums[0] for j in range(K)]
    for i in range(1, N):
        d = sums[i] + 1
        p = [p[j] * (buckets[i][j] + 1) / d + (1 - p[j]) * buckets[i][j] / d for j in range(K)]
    return p

if __name__ == "__main__":
    N, K = map(int, input("Enter N and K: ").split())
    buckets = [list(map(int, input().split())) for _ in range(N)]
    probs = bucket_chain_probability(buckets)
    print(*[f'{x:.6f}' for x in probs])
