# Q60. Maximum Sum Path in Binary Tree
class TreeNode:
    def __init__(self, v, l=None, r=None):
        self.val = v
        self.left = l
        self.right = r

def max_path_sum(root):
    best = [float('-inf')]

    def dfs(node):
        if not node:
            return 0
        l = max(dfs(node.left), 0)
        r = max(dfs(node.right), 0)
        best[0] = max(best[0], node.val + l + r)
        return node.val + max(l, r)

    dfs(root)
    return best[0]

if __name__ == "__main__":
    # Example: Tree [-10,9,20,None,None,15,7]
    root = TreeNode(-10, TreeNode(9), TreeNode(20, TreeNode(15), TreeNode(7)))
    print(max_path_sum(root))
