# Q50. Array Integer Sequences - Count Divisor Chains
MOD = 10 ** 9 + 7

def count_divisor_chains(N, K):
    dp = [[0] * (N + 1) for _ in range(K + 1)]
    for i in range(1, N + 1):
        dp[1][i] = 1
    for length in range(2, K + 1):
        for num in range(1, N + 1):
            d = 1
            while d * d <= num:
                if num % d == 0:
                    dp[length][num] = (dp[length][num] + dp[length - 1][d]) % MOD
                    if d != num // d:
                        dp[length][num] = (dp[length][num] + dp[length - 1][num // d]) % MOD
                d += 1
    return sum(dp[K][1:N + 1]) % MOD

if __name__ == "__main__":
    N, K = map(int, input("Enter N and K: ").split())
    print(count_divisor_chains(N, K))
