# Q53. 0-1 Knapsack Problem
def knapsack(N, C, W, V):
    dp = [0] * (C + 1)
    for i in range(N):
        for c in range(C, W[i] - 1, -1):
            dp[c] = max(dp[c], dp[c - W[i]] + V[i])
    return dp[C]

if __name__ == "__main__":
    N, C = map(int, input("Enter N and C: ").split())
    W = list(map(int, input("Enter weights: ").split()))
    V = list(map(int, input("Enter values: ").split()))
    print(knapsack(N, C, W, V))
