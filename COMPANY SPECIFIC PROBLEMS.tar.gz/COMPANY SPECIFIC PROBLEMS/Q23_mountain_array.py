# Q23. Mountain Array Transformation
# A "mountain" here has equal ends; moving from each end toward the middle,
# values increase by exactly 1 each step (symmetric pyramid).
# For a valid mountain with base value V, position i must equal
# V + min(i, N-1-i). Find the V (and implied shape) that matches the most
# existing elements; the minimum changes = N - max matches.
def min_changes(A):
    N = len(A)
    dist = [min(i, N - 1 - i) for i in range(N)]
    candidates = set(A[i] - dist[i] for i in range(N))
    best = 0
    for V in candidates:
        matches = sum(1 for i in range(N) if A[i] == V + dist[i])
        best = max(best, matches)
    return N - best

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = list(map(int, input("Enter array: ").split()))
    print(min_changes(A))
