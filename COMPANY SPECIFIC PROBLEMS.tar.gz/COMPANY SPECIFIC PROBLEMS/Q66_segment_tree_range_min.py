# Q66. Segment Tree - Range Minimum Query
INF = float('inf')

def build(t, A, nd, s, e):
    if s == e:
        t[nd] = A[s]
        return
    m = (s + e) // 2
    build(t, A, 2 * nd, s, m)
    build(t, A, 2 * nd + 1, m + 1, e)
    t[nd] = min(t[2 * nd], t[2 * nd + 1])

def update(t, nd, s, e, i, v):
    if s == e:
        t[nd] = v
        return
    m = (s + e) // 2
    if i <= m:
        update(t, 2 * nd, s, m, i, v)
    else:
        update(t, 2 * nd + 1, m + 1, e, i, v)
    t[nd] = min(t[2 * nd], t[2 * nd + 1])

def query(t, nd, s, e, l, r):
    if r < s or e < l:
        return INF
    if l <= s and e <= r:
        return t[nd]
    m = (s + e) // 2
    return min(query(t, 2 * nd, s, m, l, r), query(t, 2 * nd + 1, m + 1, e, l, r))

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = list(map(int, input("Enter array: ").split()))
    t = [0] * (4 * N)
    build(t, A, 1, 0, N - 1)
    Q = int(input("Enter Q: "))
    for _ in range(Q):
        ops = list(map(int, input().split()))
        if ops[0] == 1:  # query L R (1-indexed)
            print(query(t, 1, 0, N - 1, ops[1] - 1, ops[2] - 1))
        else:  # update index value (1-indexed)
            update(t, 1, 0, N - 1, ops[1] - 1, ops[2])
