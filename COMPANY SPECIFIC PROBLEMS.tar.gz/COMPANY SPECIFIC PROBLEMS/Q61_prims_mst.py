# Q61. Minimum Cost to Connect All Points (Prim's MST, Manhattan distance)
import heapq

def min_cost_connect_points(points):
    N = len(points)
    visited = [False] * N
    heap = [(0, 0)]
    total = 0
    while heap:
        cost, u = heapq.heappop(heap)
        if visited[u]:
            continue
        visited[u] = True
        total += cost
        for v in range(N):
            if not visited[v]:
                d = abs(points[u][0] - points[v][0]) + abs(points[u][1] - points[v][1])
                heapq.heappush(heap, (d, v))
    return total

if __name__ == "__main__":
    N = int(input("Enter N: "))
    points = [list(map(int, input().split())) for _ in range(N)]
    print(min_cost_connect_points(points))
