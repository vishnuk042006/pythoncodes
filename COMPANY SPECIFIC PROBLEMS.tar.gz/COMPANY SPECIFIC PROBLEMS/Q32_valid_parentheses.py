# Q32. Valid Parentheses
def is_valid(s):
    stack = []
    match = {')': '(', ']': '[', '}': '{'}
    for c in s:
        if c in match:
            if not stack or stack[-1] != match[c]:
                return False
            stack.pop()
        else:
            stack.append(c)
    return not stack

if __name__ == "__main__":
    S = input("Enter string: ")
    print(is_valid(S))
