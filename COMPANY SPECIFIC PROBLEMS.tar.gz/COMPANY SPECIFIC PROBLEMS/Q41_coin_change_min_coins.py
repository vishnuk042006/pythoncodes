# Q41. Coin Change - Minimum Coins
def min_coins(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    for a in range(1, amount + 1):
        for c in coins:
            if c <= a and dp[a - c] + 1 < dp[a]:
                dp[a] = dp[a - c] + 1
    return -1 if dp[amount] == float('inf') else dp[amount]

if __name__ == "__main__":
    coins = list(map(int, input("Enter coins: ").split()))
    amount = int(input("Enter amount: "))
    print(min_coins(coins, amount))
