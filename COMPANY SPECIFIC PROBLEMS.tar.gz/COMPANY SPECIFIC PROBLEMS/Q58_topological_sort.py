# Q58. Topological Sort (Course Schedule)
from collections import deque

def can_finish(N, prereqs):
    g = [[] for _ in range(N)]
    indeg = [0] * N
    for a, b in prereqs:
        g[b].append(a)
        indeg[a] += 1
    q = deque(i for i in range(N) if indeg[i] == 0)
    count = 0
    while q:
        u = q.popleft()
        count += 1
        for v in g[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    return count == N

if __name__ == "__main__":
    N, M = map(int, input("Enter N and M: ").split())
    prereqs = [tuple(map(int, input().split())) for _ in range(M)]
    print("YES" if can_finish(N, prereqs) else "NO")
