# Q40. Subarray with Given Sum (Non-negative)
def subarray_with_sum(A, K):
    l = s = 0
    for r in range(len(A)):
        s += A[r]
        while s > K and l <= r:
            s -= A[l]
            l += 1
        if s == K:
            return l + 1, r + 1
    return -1, None

if __name__ == "__main__":
    N, K = map(int, input("Enter N and K: ").split())
    A = list(map(int, input("Enter array: ").split()))
    l, r = subarray_with_sum(A, K)
    if l == -1:
        print(-1)
    else:
        print(l, r)
