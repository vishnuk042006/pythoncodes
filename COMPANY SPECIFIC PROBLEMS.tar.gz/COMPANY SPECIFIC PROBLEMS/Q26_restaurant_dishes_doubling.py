# Q26. Restaurant Dishes - Doubling Orders
# Rule: order req dishes of one type, then next order must be exactly
# 2*req dishes of a DIFFERENT type, then 4*req, etc. Choose the starting
# req and which types to use (in increasing-count order, taking the
# smallest sufficient count first to preserve larger counts for later,
# bigger requirements) to maximize total dishes eaten.
from collections import Counter

def max_dishes(A):
    freq = sorted(Counter(A).values())  # ascending
    best = 0
    for s in set(freq):
        total = 0
        req = s
        for val in freq:
            if val >= req:
                total += req
                req *= 2
        best = max(best, total)
    return best

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = [int(input()) for _ in range(N)]
    print(max_dishes(A))
