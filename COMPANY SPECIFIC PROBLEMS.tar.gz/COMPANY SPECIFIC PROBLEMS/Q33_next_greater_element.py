# Q33. Next Greater Element
def next_greater(A):
    N = len(A)
    res = [-1] * N
    stack = []
    for i in range(N):
        while stack and A[stack[-1]] < A[i]:
            res[stack.pop()] = A[i]
        stack.append(i)
    return res

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = list(map(int, input("Enter array: ").split()))
    print(next_greater(A))
