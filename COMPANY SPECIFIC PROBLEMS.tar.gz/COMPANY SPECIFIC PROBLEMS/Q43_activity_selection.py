# Q43. Activity Selection (Maximum Non-Overlapping Intervals)
def activity_selection(start, end):
    acts = sorted(zip(start, end), key=lambda x: x[1])
    count = 0
    last = -1
    for s, e in acts:
        if s >= last:
            count += 1
            last = e
    return count

if __name__ == "__main__":
    N = int(input("Enter N: "))
    start = list(map(int, input("Enter start times: ").split()))
    end = list(map(int, input("Enter end times: ").split()))
    print(activity_selection(start, end))
