# Q42. Top K Frequent Elements
from collections import Counter

def top_k_frequent(A, K):
    return [x for x, _ in Counter(A).most_common(K)]

if __name__ == "__main__":
    N, K = map(int, input("Enter N and K: ").split())
    A = list(map(int, input("Enter array: ").split()))
    print(*top_k_frequent(A, K))
