# Q63. Ugliness Minimization - Greedy + Bit Manipulation
# Choose XOR value B to minimize inversions in A[i]^B, processing bit by bit
# from the most significant bit down (classic trie/greedy bit-DP approach).
def min_inversions_xor(A, bits=30):
    def solve(arr, bit):
        if bit < 0 or len(arr) <= 1:
            return 0, 0
        # Count pairs where a "1"-bit element appears before a "0"-bit element
        cross0 = 0
        ones_seen = 0
        for x in arr:
            if (x >> bit) & 1:
                ones_seen += 1
            else:
                cross0 += ones_seen
        zeros = [x for x in arr if not (x >> bit) & 1]
        ones = [x for x in arr if (x >> bit) & 1]
        cross1 = len(zeros) * len(ones) - cross0

        inv_z, b_z = solve(zeros, bit - 1)
        inv_o, b_o = solve(ones, bit - 1)
        inner = inv_z + inv_o

        if cross0 <= cross1:
            return inner + cross0, b_z | b_o          # B's bit = 0
        else:
            return inner + cross1, (b_z | b_o) | (1 << bit)  # B's bit = 1

    return solve(A, bits - 1)

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = list(map(int, input("Enter array: ").split()))
    inv, B = min_inversions_xor(A)
    print(inv)
    print(f"B={B}")
