# Q70. Matrix Chain Multiplication - Minimum Operations
def matrix_chain_order(dims):
    m = len(dims) - 1
    dp = [[0] * m for _ in range(m)]
    for length in range(2, m + 1):
        for i in range(m - length + 1):
            j = i + length - 1
            dp[i][j] = float('inf')
            for k in range(i, j):
                cost = dp[i][k] + dp[k + 1][j] + dims[i] * dims[k + 1] * dims[j + 1]
                if cost < dp[i][j]:
                    dp[i][j] = cost
    return dp[0][m - 1]

if __name__ == "__main__":
    N = int(input("Enter N: "))
    dims = list(map(int, input("Enter dimensions: ").split()))
    print(matrix_chain_order(dims))
