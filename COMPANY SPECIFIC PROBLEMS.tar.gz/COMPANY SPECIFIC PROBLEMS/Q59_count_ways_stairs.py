# Q59. Count Ways to Reach N-th Stair
MOD = 10 ** 9 + 7

def count_ways(N):
    a, b = 1, 1
    for _ in range(N - 1):
        a, b = b, (a + b) % MOD
    return b

if __name__ == "__main__":
    N = int(input("Enter N: "))
    print(count_ways(N))
