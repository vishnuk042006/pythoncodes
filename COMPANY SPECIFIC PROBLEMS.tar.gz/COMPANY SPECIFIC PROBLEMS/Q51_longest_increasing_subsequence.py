# Q51. Longest Increasing Subsequence (Patience Sorting)
import bisect

def lis_length(A):
    tails = []
    for x in A:
        pos = bisect.bisect_left(tails, x)
        if pos == len(tails):
            tails.append(x)
        else:
            tails[pos] = x
    return len(tails)

if __name__ == "__main__":
    N = int(input("Enter N: "))
    A = list(map(int, input("Enter array: ").split()))
    print(lis_length(A))
